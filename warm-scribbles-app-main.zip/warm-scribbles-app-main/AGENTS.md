<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep portfolio case study text in the shared content catalog and use parentSlug to nest AWS subprojects; this preserves stable URLs and shared rendering.
- Keep project media in a shared catalog of Lovable Assets pointers and render full-size images through the reusable gallery; this keeps previews and case studies consistent without duplicating binary media.
- Keep recordings in the shared media catalog and render them with the reusable video player; this keeps homepage and case-study playback consistent.
