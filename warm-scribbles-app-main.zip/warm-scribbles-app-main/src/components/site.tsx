import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { LINKS, NAME } from "@/lib/content";

export function FlowDiagram({ steps, compact = false }: { steps: string[]; compact?: boolean }) {
  return (
    <ol className="flex flex-wrap items-center gap-y-2 font-mono text-xs" aria-label="Data flow">
      {steps.map((s, i) => (
        <li key={s} className="flex items-center">
          <span className={`rounded-md border bg-card px-2.5 py-1.5 text-foreground ${compact ? "" : "shadow-sm"}`}>{s}</span>
          {i < steps.length - 1 && <span aria-hidden className="mx-1.5 text-accent">→</span>}
        </li>
      ))}
    </ol>
  );
}

export function Btn({ href, children, variant = "solid" }: { href: string; children: ReactNode; variant?: "solid" | "outline" | "ghost" }) {
  const ext = href.startsWith("http") || href.startsWith("mailto");
  const cls = {
    solid: "bg-primary text-primary-foreground hover:bg-primary/85",
    outline: "border bg-card text-foreground hover:border-foreground/40",
    ghost: "text-foreground underline-offset-4 hover:underline px-0",
  }[variant];
  return (
    <a href={href} {...(ext && href.startsWith("http") ? { target: "_blank", rel: "noreferrer" } : {})}
      className={`inline-flex min-h-11 items-center justify-center gap-1.5 rounded-lg px-4 text-sm font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring ${cls}`}>
      {children}
    </a>
  );
}

const NAV = [["Home", "top"], ["Work", "work"], ["Experience", "experience"], ["Skills", "skills"], ["About", "about"], ["Contact", "contact"]];

export function Nav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5" aria-label="Main">
        <Link to="/" className="font-semibold tracking-tight">{NAME}<span className="text-accent">.</span></Link>
        <ul className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          {NAV.map(([l, id]) => <li key={id}><a className="hover:text-foreground" href={`/#${id}`}>{l}</a></li>)}
        </ul>
        <div className="hidden md:block"><Btn href={LINKS.resume}>View Resume</Btn></div>
        <button className="min-h-11 px-2 text-sm font-medium md:hidden" aria-expanded={open} aria-controls="mnav" onClick={() => setOpen(!open)}>
          {open ? "Close" : "Menu"}
        </button>
      </nav>
      {open && (
        <ul id="mnav" className="border-t px-5 pb-4 md:hidden">
          {NAV.map(([l, id]) => <li key={id}><a onClick={() => setOpen(false)} className="block py-3 text-base" href={`/#${id}`}>{l}</a></li>)}
          <li className="pt-2"><Btn href={LINKS.resume}>View Resume</Btn></li>
        </ul>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-semibold">{NAME}</p>
          <p className="text-sm text-muted-foreground">Data & Analytics Engineer</p>
          <p className="font-mono text-xs text-muted-foreground">Cloud Data · FinTech · BI · Applied AI</p>
        </div>
        <ul className="flex flex-wrap gap-5 text-sm">
          {([["GitHub", LINKS.github], ["LinkedIn", LINKS.linkedin], ["Medium", LINKS.medium], ["Email", LINKS.email], ["Resume", LINKS.resume]] as [string, string][]).map(([l, h]) => (
            <li key={l}><a href={h} {...(h.startsWith("http") ? { target: "_blank", rel: "noreferrer" } : {})} className="text-muted-foreground hover:text-foreground">{l}</a></li>
          ))}
        </ul>
      </div>
    </footer>
  );
}

export function SectionHead({ eyebrow, title, sub }: { eyebrow: string; title: string; sub?: string }) {
  return (
    <div className="mb-6 max-w-2xl">
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">{title}</h2>
      {sub && <p className="mt-3 text-muted-foreground">{sub}</p>}
    </div>
  );
}
