import { useState } from "react";
import { Expand } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import type { ProjectImage } from "@/lib/project-media";

export function ProjectGallery({ images, title = "Project visuals" }: { images: ProjectImage[]; title?: string }) {
  const [selected, setSelected] = useState<ProjectImage | null>(null);
  if (!images.length) return null;
  return (
    <section className="mt-6 border-t pt-6" aria-label={title}>
      <h2 className="mb-5 text-xl font-semibold">{title}</h2>
      <div className="grid gap-6">
        {images.map((image) => (
          <figure key={image.src}>
            <div className="relative overflow-hidden rounded-lg border bg-surface">
              <img src={image.src} alt={image.caption} loading="lazy" className="block h-auto w-full" />
              <Button size="icon" variant="outline" className="absolute bottom-3 right-3" aria-label={`Enlarge: ${image.caption}`} title="Enlarge image" onClick={() => setSelected(image)}>
                <Expand className="size-4" />
              </Button>
            </div>
            <figcaption className="mt-2 text-sm text-muted-foreground">{image.caption}</figcaption>
          </figure>
        ))}
      </div>
      <Dialog open={selected !== null} onOpenChange={(open) => { if (!open) setSelected(null); }}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-[min(95vw,1400px)]">
          <DialogTitle className="pr-6 text-base">{selected?.caption}</DialogTitle>
          {selected && <img src={selected.src} alt={selected.caption} className="h-auto w-full" />}
        </DialogContent>
      </Dialog>
    </section>
  );
}