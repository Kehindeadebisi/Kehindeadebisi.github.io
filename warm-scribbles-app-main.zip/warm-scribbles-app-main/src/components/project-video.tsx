import type { ProjectVideo as Video } from "@/lib/project-media";

export function ProjectVideo({ video }: { video: Video | undefined }) {
  if (!video) return null;
  return (
    <figure>
      <video controls preload="metadata" playsInline className="aspect-video w-full rounded-md bg-surface" aria-label={video.caption}>
        <source src={video.webm} type="video/webm" />
        <source src={video.src} type="video/mp4" />
        <a href={video.src}>View recording</a>
      </video>
      <figcaption className="mt-2 text-xs text-muted-foreground">{video.caption}</figcaption>
    </figure>
  );
}