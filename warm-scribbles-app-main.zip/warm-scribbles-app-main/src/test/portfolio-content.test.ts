import { describe, expect, it } from "vitest";
import { EDUCATION, LINKS, NAME, PROJECTS } from "@/lib/content";
import { ARCHIVE_MEDIA, PROJECT_MEDIA, PROJECT_VIDEOS, VBA_VIDEO } from "@/lib/project-media";

describe("Portfolio content updates", () => {
  it("keeps old case study URLs while replacing their content", () => {
    expect(PROJECTS.find((p) => p.slug === "profit-distribution-engine")?.title).toBe("Automated Profit Distribution Report Generator");
    expect(PROJECTS.find((p) => p.slug === "reliability-data-pipeline")?.stack).toContain("n8n");
  });
  it("nests the legal assistant under AWS", () => {
    expect(PROJECTS.find((p) => p.slug === "legal-knowledge-base")?.parentSlug).toBe("aws-data-ml-platform");
  });
  it("uses corrected presentations and resume", () => {
    expect(LINKS.resume).toContain("13gx94VEkUBiwtaAFfCkieds04S62IQQp");
    expect(LINKS.credentials).toContain("/wallet");
    expect(PROJECTS.find((p) => p.slug === "liquidity-intelligence")?.links.find((l) => l.label === "Presentation")?.href).toContain("1sh9UR5H0sJY6wPIwC_76AW9I-V50Oxwk/edit?pli=1");
    expect(PROJECTS.find((p) => p.slug === "automated-financial-reporting")?.links[0]?.href).toContain("usp=sharing");
  });
  it("provides relevant visuals for the financial and engineering studies", () => {
    for (const slug of ["bedrest-data-model", "automated-financial-reporting", "profit-distribution-engine", "reliability-data-pipeline", "legal-knowledge-base"]) {
      expect(PROJECT_MEDIA[slug]?.length).toBeGreaterThan(0);
    }
  });
  it("uses the replacement recordings and removes Excel screenshots", () => {
    expect(PROJECT_VIDEOS["liquidity-intelligence"]?.src).toContain("liquidity-demo.mp4");
    expect(VBA_VIDEO.src).toContain("ff0d7cb9-897b-42e6-9744-c98b2597cf80");
    expect(ARCHIVE_MEDIA["Excel VBA Data Entry System"]).toBeUndefined();
  });
  it("uses the corrected name, links and education entries", () => {
    expect(NAME).toBe("Kehinde Adebisi");
    expect(LINKS.linkedin).toBe("https://www.linkedin.com/in/kehindeadebisi");
    expect(LINKS.email).toBe("mailto:roheemahadebisi@gmail.com");
    expect(LINKS.emailAddress).toBe("roheemahadebisi@gmail.com");
    expect(EDUCATION.map((e) => e.program)).toEqual([
      "Data Science, ML, and AI",
      "Backend Software Development",
      "M.Ed Counselling Psychology",
      "B.Sc (Ed) Guidance & Counselling / Chemistry",
    ]);
    expect(EDUCATION[0]?.org).toBe("Women Techsters Fellowship, Tech4Dev");
    expect(EDUCATION[0]?.note).toBe("Summa cum laude");
    expect(EDUCATION[1]?.org).toBe("Stutern Graduate Accelerator, Nigeria");
  });
});