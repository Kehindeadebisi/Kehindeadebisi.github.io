import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Btn, FlowDiagram, Footer, Nav } from "@/components/site";
import { PROJECTS } from "@/lib/content";
import { PROJECT_MEDIA, PROJECT_VIDEOS } from "@/lib/project-media";
import { ProjectVideo } from "@/components/project-video";
import { ProjectGallery } from "@/components/project-gallery";

export const Route = createFileRoute("/work/$slug")({
  loader: ({ params }) => {
    const project = PROJECTS.find((p) => p.slug === params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Project not found" }, { name: "robots", content: "noindex" }] };
    const p = loaderData.project;
    const t = `${p.title} — Case Study | Kehinde Adebisi`;
    return {
      meta: [
        { title: t },
        { name: "description", content: p.summary },
        { property: "og:title", content: t },
        { property: "og:description", content: p.summary },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: ProjectMissing,
  component: CaseStudy,
});

function ProjectMissing() {
  return (
    <div className="mx-auto max-w-xl px-5 py-24 text-center">
      <h1 className="text-2xl font-semibold">Project not found</h1>
      <Link to="/" hash="work" className="mt-4 inline-block text-accent underline">Back to projects</Link>
    </div>
  );
}

function CaseStudy() {
  const { project: p } = Route.useLoaderData();
  const idx = PROJECTS.findIndex((x) => x.slug === p.slug);
  const next = PROJECTS[(idx + 1) % PROJECTS.length];
  const children = PROJECTS.filter((child) => child.parentSlug === p.slug);
  const parent = PROJECTS.find((project) => project.slug === p.parentSlug);
  return (
    <>
      <Nav />
      <main className="mx-auto max-w-6xl px-5 py-8">
        <Link to="/" hash="work" className="font-mono text-xs text-muted-foreground hover:text-foreground">← Back to Projects</Link>
        <header className="mt-6 max-w-3xl">
          <p className="eyebrow">{p.label}</p>
          {parent && <Link to="/work/$slug" params={{ slug: parent.slug }} className="mt-3 block text-sm text-accent hover:underline">Part of {parent.title} →</Link>}
          <h1 className="mt-3 text-3xl font-semibold tracking-tight md:text-5xl">{p.title}</h1>
          <p className="mt-3 text-sm text-muted-foreground">{p.tags.join(" · ")}</p>
          <p className="mt-5 text-lg text-muted-foreground">{p.summary}</p>
          <p className="mt-3 text-sm"><span className="font-medium">Role:</span> {p.role}</p>
          {p.links.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-3">{p.links.map((l, i) => <Btn key={l.href} href={l.href} variant={i === 0 ? "solid" : "outline"}>{l.label} ↗</Btn>)}</div>
          )}
        </header>

        <div className="mt-6 rounded-xl border bg-surface p-4">
          <p className="mb-3 font-mono text-xs uppercase text-muted-foreground">Architecture</p>
          <FlowDiagram steps={p.flow} />
        </div>

        <ProjectGallery images={PROJECT_MEDIA[p.slug] ?? []} title={p.slug === "bedrest-data-model" || p.slug === "automated-financial-reporting" ? "Reporting views" : "Architecture & workflow"} />
        {PROJECT_VIDEOS[p.slug] && <section className="mt-6 border-t pt-6" aria-label="Project recording"><ProjectVideo video={PROJECT_VIDEOS[p.slug]} /></section>}

        {children.length > 0 && (
          <section className="mt-10 border-t pt-8">
            <h2 className="text-xl font-semibold">Platform projects</h2>
            {children.map((child) => (
              <div key={child.slug} className="mt-6 grid items-start gap-6 md:grid-cols-2">
                <Link to="/work/$slug" params={{ slug: child.slug }} className="overflow-hidden rounded-lg border bg-surface">
                  <img src={PROJECT_MEDIA[child.slug]?.[0]?.src} alt={`${child.title} architecture`} loading="lazy" className="h-auto w-full" />
                </Link>
                <div>
                  <h3 className="text-lg font-semibold">{child.title}</h3>
                  <p className="mt-2 text-muted-foreground">{child.summary}</p>
                  <p className="mt-3 font-mono text-xs text-muted-foreground">{child.stack.join(" · ")}</p>
                  <Link to="/work/$slug" params={{ slug: child.slug }} className="mt-4 inline-block text-sm font-medium text-accent hover:underline">Read case study →</Link>
                </div>
              </div>
            ))}
          </section>
        )}

        <div className="mt-8 grid gap-6 md:grid-cols-[200px_1fr]">
          <nav aria-label="Case study sections" className="hidden md:block">
            <ul className="sticky top-24 space-y-1.5 font-mono text-xs text-muted-foreground">
              {p.study.map((s, i) => <li key={s.heading}><a href={`#s${i}`} className="hover:text-foreground">{String(i + 1).padStart(2, "0")} — {s.heading}</a></li>)}
            </ul>
          </nav>
          <div className="space-y-6">
            {p.study.map((s, i) => (
              <section key={s.heading} id={`s${i}`}>
                <p className="font-mono text-xs text-accent">{String(i + 1).padStart(2, "0")}</p>
                <h2 className="mt-1 text-xl font-semibold">{s.heading}</h2>
                <p className="mt-2 max-w-2xl whitespace-pre-line text-muted-foreground">{s.body}</p>
              </section>
            ))}
            <section>
              <h2 className="text-xl font-semibold">Key technologies</h2>
              <ul className="mt-3 flex flex-wrap gap-1.5">{p.stack.map((s) => <li key={s} className="rounded-md border bg-card px-2 py-1 font-mono text-xs">{s}</li>)}</ul>
            </section>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-3 border-t pt-6 sm:flex-row sm:justify-between">
          <Link to="/" hash="work" className="text-sm text-muted-foreground hover:text-foreground">← Back to Projects</Link>
          {next && <Link to="/work/$slug" params={{ slug: next.slug }} className="text-sm font-medium hover:text-accent">Next: {next.title} →</Link>}
        </div>
      </main>
      <Footer />
    </>
  );
}
