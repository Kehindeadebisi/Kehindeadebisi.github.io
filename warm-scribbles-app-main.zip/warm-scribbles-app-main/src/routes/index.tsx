import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Btn, FlowDiagram, Footer, Nav, SectionHead } from "@/components/site";
import { EARLIER_ML, EDUCATION, EXPERIENCE, LINKS, MORE_WORK, NAME, PROJECTS, SKILLS, type Cat } from "@/lib/content";
import { ARCHIVE_MEDIA, PROJECT_MEDIA, PROJECT_VIDEOS, VBA_VIDEO } from "@/lib/project-media";
import { ProjectVideo } from "@/components/project-video";

const TITLE = "Kehinde Adebisi — Data & Analytics Engineer | Cloud Data · FinTech · BI · Applied AI";
const DESC = "Data & Analytics Engineer specialising in cloud data, FinTech, business intelligence, data engineering and applied AI. Explore selected data systems, financial analytics and cloud projects.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const PIPE = [
  ["01", "Ingest", "APIs · CSV · Operational Systems · Cloud Sources"],
  ["02", "Engineer", "Python · SQL · Bash · ETL/ELT · Airflow"],
  ["03", "Model", "Dimensional Modeling · Data Warehousing · Power Pivot"],
  ["04", "Cloud", "AWS · Azure · S3 · Glue · Redshift · Lambda · SageMaker"],
  ["05", "Analyze", "Pandas · Power BI · DAX · Tableau · Excel"],
  ["06", "Predict", "Forecasting · XGBoost · Monte Carlo · Applied ML"],
  ["07", "Deliver", "Dashboards · Streamlit · Automated Reporting · Decision Support"],
];

const BRING = [
  ["Data Engineering", "Python, SQL, ETL/ELT, data pipelines, AWS Glue, S3, Redshift, APIs, transformation."],
  ["Cloud", "AWS and Azure cloud data platforms, serverless workflows, storage, databases and production infrastructure."],
  ["Analytics & BI", "Power BI, DAX, Excel, Tableau, KPI development, data modeling and business reporting."],
  ["Applied AI", "Forecasting, machine learning, XGBoost, SageMaker, AI-assisted analysis and decision support."],
  ["FinTech", "Financial analytics, liquidity intelligence, financial modelling, operational data and financial process automation."],
];

const WHY = [
  ["I understand the system around the data", "My background spans data, cloud infrastructure, automation and production systems. I understand that good analytics depends on reliable data pipelines and reliable systems."],
  ["I understand financial problems", "My experience across fintech, financial analytics, banking and financial modelling helps me connect technical work to real financial and operational decisions."],
  ["I build, not just analyze", "From ETL pipelines and cloud platforms to forecasting applications, BI models and automated reporting, I like taking a problem all the way from raw data to usable output."],
];

const FILTERS: ("All" | Cat)[] = ["All", "Data Engineering", "BI", "FinTech", "ML", "Cloud", "Automation"];

function Home() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const work = filter === "All" ? MORE_WORK : MORE_WORK.filter((w) => w.cats.includes(filter as Cat));

  return (
    <>
      <Nav />
      <main id="top">
        {/* Hero */}
        <section className="relative overflow-hidden border-b">
          <div className="grid-bg absolute inset-0 opacity-40 [mask-image:linear-gradient(to_bottom,black,transparent)]" aria-hidden />
          <div className="relative mx-auto grid max-w-6xl gap-6 px-5 py-8 md:grid-cols-[1.25fr_1fr] md:py-10">
            <div>
              <p className="eyebrow">{NAME} · Data & Analytics Engineer</p>
              <h1 className="mt-4 text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
                Building reliable data systems that turn information into decisions.
              </h1>
              <p className="mt-5 font-mono text-sm text-accent">Cloud Data · FinTech · BI · Applied AI</p>
              <p className="mt-5 max-w-xl text-lg text-muted-foreground">
                I build data pipelines, analytical systems and intelligent financial solutions—from cloud data platforms and production workflows to BI models, forecasting applications and automated decision support.
              </p>
              <div className="mt-5 flex flex-wrap gap-3">
                <Btn href="#work">View Selected Work</Btn>
                <Btn href={LINKS.resume} variant="outline">View Resume</Btn>
              </div>
            </div>
            <div className="self-center rounded-xl border bg-card p-5 shadow-sm">
              <div className="mb-4 flex items-center justify-between font-mono text-xs text-muted-foreground">
                <span>pipeline.yaml</span><span className="text-accent">● running</span>
              </div>
              <ol className="space-y-0">
                {PIPE.map(([n, name], i) => (
                  <li key={n}>
                    <div className="flex items-center gap-3 rounded-md px-2 py-1.5 hover:bg-surface">
                      <span className="font-mono text-xs text-muted-foreground">{n}</span>
                      <span className="text-sm font-medium">{name}</span>
                    </div>
                    {i < PIPE.length - 1 && <div className="ml-[1.1rem] h-3 w-px bg-accent/40" aria-hidden />}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </section>

        {/* What I bring */}
        <section className="mx-auto max-w-6xl px-5 py-10">
          <SectionHead eyebrow="Capabilities" title="What I bring" sub="I don't just work with data. I build around it." />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {BRING.map(([t, d]) => (
              <div key={t} className="rounded-xl border bg-card p-5">
                <h3 className="font-semibold">{t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
          <ul className="mt-5 grid gap-2 font-mono text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-3">
            {["Operational signals → reliable reporting", "Raw financial data → forecasting and liquidity intelligence", "Business rules → financial allocation and reporting", "Multiple data sources → cloud data pipelines", "Business processes → automated data workflows"].map((x) => (
              <li key={x} className="rounded-md bg-surface px-3 py-2">{x}</li>
            ))}
          </ul>
        </section>

        {/* Raw to decision */}
        <section className="border-y bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-10">
            <SectionHead eyebrow="Lifecycle" title="From raw data to decision" sub="The complete data lifecycle — and the tools I use at each stage." />
            <ol className="grid gap-px overflow-hidden rounded-xl border bg-border md:grid-cols-7">
              {PIPE.map(([n, name, tools]) => (
                <li key={n} className="bg-card p-4">
                  <p className="font-mono text-xs text-accent">{n}</p>
                  <h3 className="mt-1 font-semibold uppercase tracking-wide">{name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{tools}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Selected work */}
        <section id="work" className="mx-auto max-w-6xl px-5 py-10">
          <SectionHead eyebrow="Selected Work" title="Selected Work" sub="A selection of data systems, analytical products and financial intelligence projects." />
          <div className="space-y-4">
            {PROJECTS.filter((p) => !p.parentSlug).map((p, i) => (
              <article key={p.slug} className="rounded-lg border bg-card p-4 md:p-5">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-xs text-muted-foreground">
                  <span className="text-accent">{String(i + 1).padStart(2, "0")}</span>
                  <span>{p.label}</span>
                </div>
                <h3 className="mt-3 text-2xl font-semibold tracking-tight">{p.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.tags.join(" · ")}</p>
                <p className="mt-4 max-w-3xl">{p.summary}</p>
                <dl className="mt-6 grid gap-5 text-sm md:grid-cols-3">
                  <div><dt className="font-mono text-xs uppercase text-muted-foreground">Problem</dt><dd className="mt-1">{p.problem}</dd></div>
                  <div><dt className="font-mono text-xs uppercase text-muted-foreground">Approach</dt><dd className="mt-1">{p.approach}</dd></div>
                  <div><dt className="font-mono text-xs uppercase text-muted-foreground">Outcome</dt><dd className="mt-1">{p.outcome}</dd></div>
                </dl>
                <div className="mt-6 rounded-lg bg-surface p-4"><FlowDiagram steps={p.flow} /></div>
                <p className="mt-4 font-mono text-xs text-muted-foreground">{p.stack.join(" · ")}</p>
                {PROJECT_MEDIA[p.slug]?.[0] && (
                  <Link to="/work/$slug" params={{ slug: p.slug }} className="mt-6 block overflow-hidden rounded-lg border bg-surface">
                    <img src={PROJECT_MEDIA[p.slug]?.[0]?.src} alt={PROJECT_MEDIA[p.slug]?.[0]?.caption} loading="lazy" className="h-auto max-h-96 w-full object-contain" />
                  </Link>
                )}
                {PROJECT_VIDEOS[p.slug] && <div className="mt-5"><ProjectVideo video={PROJECT_VIDEOS[p.slug]} /></div>}
                {PROJECTS.filter((child) => child.parentSlug === p.slug).map((child) => (
                  <div key={child.slug} className="mt-6 grid gap-5 border-t pt-6 sm:grid-cols-[1fr_1.3fr]">
                    <Link to="/work/$slug" params={{ slug: child.slug }} className="overflow-hidden rounded-lg border bg-surface">
                      <img src={PROJECT_MEDIA[child.slug]?.[0]?.src} alt="Legal Knowledge Base Assistant architecture" loading="lazy" className="h-auto w-full" />
                    </Link>
                    <div>
                      <p className="font-mono text-xs text-accent">AWS platform project</p>
                      <h4 className="mt-2 text-xl font-semibold">{child.title}</h4>
                      <p className="mt-2 text-sm text-muted-foreground">{child.summary}</p>
                      <p className="mt-3 font-mono text-xs text-muted-foreground">{child.stack.join(" · ")}</p>
                      <Link to="/work/$slug" params={{ slug: child.slug }} className="mt-4 inline-block text-sm font-medium text-accent hover:underline">Read case study →</Link>
                    </div>
                  </div>
                ))}
                <div className="mt-6 flex flex-wrap gap-3">
                  <Link to="/work/$slug" params={{ slug: p.slug }} className="inline-flex min-h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground hover:bg-primary/85">Case Study →</Link>
                  {p.links.map((l) => <Btn key={l.href} href={l.href} variant="outline">{l.label}</Btn>)}
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Why different */}
        <section className="bg-primary text-primary-foreground">
          <div className="mx-auto max-w-6xl px-5 py-10">
            <p className="eyebrow">Differentiator</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">Why my background is different</h2>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {WHY.map(([t, d]) => (
                <div key={t} className="rounded-xl border border-primary-foreground/15 p-4">
                  <h3 className="text-lg font-semibold">{t}</h3>
                  <p className="mt-3 text-sm text-primary-foreground/75">{d}</p>
                </div>
              ))}
            </div>
            <p className="mt-6 font-mono text-sm text-primary-foreground/75">From messy data to reliable systems, useful analysis and actionable decisions.</p>
          </div>
        </section>

        {/* Experience */}
        <section id="experience" className="mx-auto max-w-6xl px-5 py-10">
          <SectionHead eyebrow="Career" title="Experience" sub="Analysis → BI → analytics engineering → cloud data → production systems." />
          <ol className="relative space-y-6 border-l pl-6 md:pl-8">
            {EXPERIENCE.map((e) => (
              <li key={e.company} className="relative">
                <span className="absolute -left-[1.85rem] top-1.5 h-3 w-3 rounded-full border-2 border-accent bg-background md:-left-[2.35rem]" aria-hidden />
                <div className="flex flex-col gap-1 md:flex-row md:items-baseline md:justify-between">
                  <h3 className="text-xl font-semibold">{e.company} <span className="font-normal text-muted-foreground">— {e.role}</span></h3>
                  <p className="font-mono text-xs text-muted-foreground">{e.period}</p>
                </div>
                <p className="mt-1 text-sm text-accent">{e.story}</p>
                <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                  {e.points.map((pt) => <li key={pt}>{pt}</li>)}
                </ul>
                <p className="mt-3 font-mono text-xs text-muted-foreground">{e.stack.join(" · ")}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* More work */}
        <section className="border-y bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-10">
            <SectionHead eyebrow="Archive" title="More data work" sub="Engineering, automation, BI and financial modelling." />
            <div className="mb-6 flex flex-wrap gap-2" role="group" aria-label="Filter projects">
              {FILTERS.map((f) => (
                <button key={f} onClick={() => setFilter(f)} aria-pressed={filter === f}
                  className={`min-h-9 rounded-full border px-3 text-sm transition-colors ${filter === f ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:border-foreground/40"}`}>
                  {f}
                </button>
              ))}
            </div>
            <div className="columns-1 gap-4 sm:columns-2 lg:columns-3">
              {work.map((w) => (
                <article key={w.title} className="group mb-4 break-inside-avoid overflow-hidden rounded-lg border bg-card hover:border-foreground/30">
                  {ARCHIVE_MEDIA[w.title]?.[0] && (
                    <img src={ARCHIVE_MEDIA[w.title]?.[0]?.src} alt={ARCHIVE_MEDIA[w.title]?.[0]?.caption} loading="lazy" className="aspect-video w-full border-b object-contain bg-surface" />
                  )}
                  <a href={w.href} target="_blank" rel="noreferrer" className="block p-4">
                  <p className="font-mono text-xs text-accent">{w.tool}</p>
                  <h3 className="mt-2 font-semibold group-hover:underline">{w.title} ↗</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{w.desc}</p>
                  <p className="mt-3 font-mono text-[11px] text-muted-foreground">{w.cats.join(" · ")}</p>
                  </a>
                  {w.title === "Excel VBA Data Entry System" && (
                    <figure className="border-t p-4">
                      <ProjectVideo video={VBA_VIDEO} />
                    </figure>
                  )}
                </article>
              ))}
              {work.length === 0 && <p className="text-sm text-muted-foreground">No projects in this category yet.</p>}
            </div>

            <h3 className="mt-8 text-lg font-semibold">Earlier Machine Learning Work</h3>
            <ul className="mt-4 divide-y rounded-xl border bg-card">
              {EARLIER_ML.map((m) => (
                <li key={m.title}>
                  <a href={m.href} target="_blank" rel="noreferrer" className="flex flex-col gap-1 px-5 py-3 text-sm hover:bg-surface md:flex-row md:justify-between">
                    <span className="font-medium">{m.title}</span>
                    <span className="text-muted-foreground md:max-w-lg md:text-right">{m.desc}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* Skills */}
        <section id="skills" className="mx-auto max-w-6xl px-5 py-10">
          <SectionHead eyebrow="Toolkit" title="Skills" />
          <div className="grid gap-px overflow-hidden rounded-xl border bg-border sm:grid-cols-2 lg:grid-cols-3">
            {Object.entries(SKILLS).map(([g, items]) => (
              <div key={g} className="bg-card p-4">
                <h3 className="font-semibold">{g}</h3>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {items.map((s) => <li key={s} className="rounded-md bg-surface px-2 py-1 font-mono text-xs">{s}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* About + credentials */}
        <section id="about" className="border-t">
          <div className="mx-auto grid max-w-6xl gap-6 px-5 py-10 md:grid-cols-[1.4fr_1fr]">
            <div>
              <p className="eyebrow">About</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight md:text-4xl">About</h2>
              <div className="mt-6 space-y-4 text-muted-foreground">
                <p>I am a Data & Analytics Engineer with a background spanning cloud data engineering, business intelligence, financial technology, machine learning and production engineering.</p>
                <p>My work has taken me from building cloud-based data workflows with AWS to developing BI models, financial analytics applications and automated operational reporting systems.</p>
                <p>I am particularly interested in problems where data engineering meets real business decisions—especially financial systems, operational intelligence and automation.</p>
                <p>I enjoy working across the stack: understanding the problem, engineering the data, modelling it, analyzing it and delivering something people can actually use.</p>
              </div>
            </div>
            <div className="space-y-5">
              <div>
                <h3 className="font-semibold">Credentials</h3>
                <p className="mt-1 text-xs text-muted-foreground">Projects prove ability; credentials add context.</p>
                <ul className="mt-3 space-y-2 text-sm">
                  {["AWS Solutions Architect", "AWS Cloud Practitioner", "Azure Database Administrator Associate", "Financial Modeling & Valuation Analyst", "Business Intelligence and Data Analysis — Corporate Finance Institute (CFI)"].map((c) => (
                    <li key={c} className="rounded-lg border bg-card px-4 py-2.5">{c}</li>
                  ))}
                </ul>
                <p className="mt-3 font-mono text-xs text-muted-foreground">CFI · Data & BI tools · Analysis · ML</p>
                <div className="mt-4"><Btn href={LINKS.credentials} variant="outline">CFI Credential Wallet ↗</Btn></div>
              </div>
              <div>
                <h3 className="font-semibold">Education</h3>
                <ul className="mt-3 space-y-3 text-sm">
                  {EDUCATION.map((e) => (
                    <li key={e.program}>
                      <p className="font-medium text-foreground">
                        {e.program}
                        {e.note && <span className="font-normal text-muted-foreground"> — {e.note}</span>}
                      </p>
                      {e.org && <p className="text-xs text-muted-foreground">{e.org}</p>}
                      {e.detail && <p className="mt-0.5 text-xs text-muted-foreground">{e.detail}</p>}
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-xs text-muted-foreground">Contributes structured problem solving, research and an understanding of stakeholders.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="border-t bg-surface">
          <div className="mx-auto max-w-6xl px-5 py-10">
            <h2 className="max-w-3xl text-3xl font-semibold tracking-tight md:text-5xl">Let's build something useful with data.</h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">I'm open to Data Engineering, Analytics Engineering, BI, Cloud Data, FinTech Data and applied data opportunities.</p>
            <a href={LINKS.email} className="mt-4 inline-block font-mono text-sm text-accent underline-offset-4 hover:underline">{LINKS.emailAddress}</a>
            <div className="mt-5 flex flex-wrap gap-3">
              <Btn href={LINKS.linkedin}>LinkedIn</Btn>
              <Btn href={LINKS.github} variant="outline">GitHub</Btn>
              <Btn href={LINKS.email} variant="outline">Email</Btn>
              <Btn href={LINKS.resume} variant="outline">Download Resume</Btn>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
