import bedrestOverview from "@/assets/bedrest-overview.png.asset.json";
import bedrestStore from "@/assets/bedrest-store.png.asset.json";
import financialIncome from "@/assets/financial-income.png.asset.json";
import financialBalance from "@/assets/financial-balance.webp.asset.json";
import trading from "@/assets/tableau-trading.png.asset.json";
import vbaVideo from "@/assets/excel-vba-demo.mp4.asset.json";
import liquidityVideo from "@/assets/liquidity-demo.mp4.asset.json";
import vbaWebm from "@/assets/excel-vba-demo.webm.asset.json";
import liquidityWebm from "@/assets/liquidity-demo.webm.asset.json";
import profitArchitecture from "@/assets/profit-architecture.png.asset.json";
import profitWorkflow from "@/assets/profit-workflow.png.asset.json";
import sreArchitecture from "@/assets/sre-architecture.png.asset.json";
import sreWorkflow from "@/assets/sre-workflow.png.asset.json";
import legalArchitecture from "@/assets/legal-architecture.png.asset.json";

export type ProjectImage = { src: string; caption: string };
export const PROJECT_MEDIA: Record<string, ProjectImage[]> = {
  "bedrest-data-model": [
    { src: bedrestOverview.url, caption: "Business Overview — sales, year-on-year performance, margins and monthly trends." },
    { src: bedrestStore.url, caption: "Store Performance — location, category, daily sales and employee performance." },
  ],
  "automated-financial-reporting": [
    { src: financialIncome.url, caption: "Income Statement — revenue, expenses, profitability and financial ratios." },
    { src: financialBalance.url, caption: "Balance Sheet — assets, liabilities, equity and quarterly liquidity ratios." },
  ],
  "profit-distribution-engine": [
    { src: profitArchitecture.url, caption: "Profit distribution architecture — investment data through settlement delivery." },
    { src: profitWorkflow.url, caption: "Profit distribution workflow — validation, allocation, AI summaries and report delivery." },
  ],
  "reliability-data-pipeline": [
    { src: sreArchitecture.url, caption: "Reliability reporting architecture — monitoring, processing, AI analysis and publishing." },
    { src: sreWorkflow.url, caption: "Scheduled reliability workflow — metric collection through Notion and Slack delivery." },
  ],
  "legal-knowledge-base": [
    { src: legalArchitecture.url, caption: "Legal knowledge assistant — serverless retrieval and grounded answers on AWS." },
  ],
};
export const ARCHIVE_MEDIA: Record<string, ProjectImage[]> = {
  "Tableau Trading Dashboard": [{ src: trading.url, caption: "Tableau market analysis — 180-day price movements and trading volume." }],
};
export type ProjectVideo = { src: string; webm: string; caption: string };
export const VBA_VIDEO: ProjectVideo = { src: vbaVideo.url, webm: vbaWebm.url, caption: "Excel VBA — data entry workflow recording." };
export const PROJECT_VIDEOS: Record<string, ProjectVideo> = {
  "liquidity-intelligence": { src: liquidityVideo.url, webm: liquidityWebm.url, caption: "Liquidity intelligence — application recording." },
};