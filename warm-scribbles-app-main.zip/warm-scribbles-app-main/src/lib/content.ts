export const NAME = "Kehinde Adebisi";

export const LINKS = {
  github: "https://github.com/Kehindeadebisi",
  linkedin: "https://www.linkedin.com/in/kehindeadebisi",
  email: "mailto:roheemahadebisi@gmail.com",
  emailAddress: "roheemahadebisi@gmail.com",
  medium: "https://medium.com/@roheemahadebisi",
  credentials: "https://credentials.corporatefinanceinstitute.com/profile/kehinderahimotadebisi531413/wallet",
  resume: "https://drive.google.com/file/d/13gx94VEkUBiwtaAFfCkieds04S62IQQp/view?usp=sharing",
};

export type Education = {
  program: string;
  org?: string;
  detail?: string;
  note?: string;
};

export const EDUCATION: Education[] = [
  {
    program: "Data Science, ML, and AI",
    org: "Women Techsters Fellowship, Tech4Dev",
    detail: "BI tools, ETL, Python, and Machine Learning Models.",
    note: "Summa cum laude",
  },
  {
    program: "Backend Software Development",
    org: "Stutern Graduate Accelerator, Nigeria",
    detail: "HTML, CSS, JavaScript, Node.js, Python, Software lifecycle, Software Testing, Database Management.",
  },
  { program: "M.Ed Counselling Psychology", note: "Distinction" },
  { program: "B.Sc (Ed) Guidance & Counselling / Chemistry", note: "First Class" },
];

export type Label = "Professional Project — anonymized for confidentiality" | "Personal Project" | "Case Study / Analytical Project";

export type Project = {
  slug: string;
  parentSlug?: string;
  title: string;
  label: Label;
  tags: string[];
  summary: string;
  role: string;
  problem: string;
  approach: string;
  outcome: string;
  stack: string[];
  flow: string[];
  links: { label: string; href: string }[];
  study: { heading: string; body: string }[];
};

const S = (
  context: string, data: string, approach: string, architecture: string, engineering: string,
  analysis: string, delivery: string, outcome: string, decisions: string, lessons: string,
) => [
  { heading: "Context", body: context },
  { heading: "Data", body: data },
  { heading: "Approach", body: approach },
  { heading: "Architecture", body: architecture },
  { heading: "Engineering", body: engineering },
  { heading: "Analysis / Intelligence", body: analysis },
  { heading: "Delivery", body: delivery },
  { heading: "Outcome", body: outcome },
  { heading: "Technical Decisions", body: decisions },
  { heading: "Lessons", body: lessons },
];

export const PROJECTS: Project[] = [
  {
    slug: "liquidity-intelligence",
    title: "FinTech Liquidity Intelligence Platform",
    label: "Personal Project",
    tags: ["Data Engineering", "Forecasting", "FinTech", "Applied ML"],
    summary: "A financial intelligence platform that transforms liquidity data into forecasting and decision-support insights.",
    role: "Designed and built end-to-end — data preparation, modelling and the Streamlit application.",
    problem: "Liquidity decisions depend on understanding how cash positions move over time. Raw financial data on its own doesn't tell a treasury or finance team what is likely to happen next.",
    approach: "Clean and structure the liquidity data with Python and SQL, analyse its behaviour, build forecasting models, and expose the results through an interactive application.",
    outcome: "A usable application that takes a financial question from raw data through to forecasts and decision-support views — not just a notebook.",
    stack: ["Python", "Pandas", "SQL", "Forecasting", "Machine Learning", "Streamlit", "Financial Modelling"],
    flow: ["Data", "Cleaning", "Forecasting", "Financial Intelligence", "Streamlit"],
    links: [
      { label: "GitHub", href: "https://github.com/Kehindeadebisi/liquidity" },
      { label: "Live demo", href: "https://liquidity-demo.streamlit.app/" },
      { label: "Presentation", href: "https://docs.google.com/presentation/d/1sh9UR5H0sJY6wPIwC_76AW9I-V50Oxwk/edit?pli=1&slide=id.p1#slide=id.p1" },
    ],
    study: S(
      "Finance teams need forward-looking visibility on liquidity, not only historical reports. The goal was to move from a financial problem to a working decision-support tool.",
      "Liquidity and cash-position data, prepared and structured for time-based analysis.",
      "Treat it as a full pipeline: prepare the data, explore its behaviour, model it, then deliver the result as an application people can interact with.",
      "Data → Cleaning → Forecasting → Financial Intelligence → Streamlit application.",
      "Data cleaning, type handling and feature preparation in Python/Pandas, with SQL used for structured querying.",
      "Exploratory analysis of liquidity behaviour and forecasting models to estimate future positions.",
      "An interactive Streamlit application with a public live demo, supported by a presentation of the approach.",
      "Demonstrates the full path: financial problem → data → analysis → model → usable application.",
      "Python and Pandas for flexible financial data work; Streamlit to deliver a usable interface quickly without a separate front-end stack.",
      "Forecasts are only useful when they are explained and accessible — delivery matters as much as the model.",
    ),
  },
  {
    slug: "aws-data-ml-platform",
    title: "AWS Data Engineering & ML Platform",
    label: "Professional Project — anonymized for confidentiality",
    tags: ["AWS", "Data Engineering", "ETL/ELT", "Machine Learning"],
    summary: "Cloud data engineering and ML workflows delivered as a Cloud Solutions Engineer – Data/AI, using AWS-native services.",
    role: "Cloud Solutions Engineer – Data/AI at Datamellon. Client and architecture specifics withheld.",
    problem: "Organisations needed data from multiple sources consolidated into reliable cloud storage and warehousing so it could support analytics and machine learning.",
    approach: "Build AWS-based ETL/ELT workflows: land data in S3, transform with Glue, load into Redshift and DynamoDB, and support ML workflows with SageMaker.",
    outcome: "Hands-on delivery in real cloud data engineering environments — beyond tutorials.",
    stack: ["AWS Glue", "Amazon S3", "Amazon Redshift", "DynamoDB", "SageMaker", "Python", "ETL/ELT"],
    flow: ["Data Sources", "S3", "Glue / ETL", "Redshift", "SageMaker / Analytics", "Outputs"],
    links: [],
    study: S(
      "Professional client work. Details are generalised to protect confidentiality.",
      "Data from multiple source systems, landed into cloud object storage.",
      "Use managed AWS services to build repeatable ingestion and transformation workflows feeding a warehouse and ML layer.",
      "Data Sources → S3 / Data Storage → Glue / ETL → Data Warehouse → Analytics / ML → Outputs.",
      "Python-based Glue jobs for transformation; S3 as the storage layer; Redshift and DynamoDB for structured and key-value access.",
      "Prepared data made available for analytics and SageMaker-based machine-learning workflows.",
      "Outputs served to downstream analytics and ML consumers.",
      "Cloud data platforms and workflows supporting analytics and ML use cases.",
      "Managed, serverless-leaning AWS services reduce operational overhead and scale with data volume.",
      "Good cloud data engineering is as much about reliability and structure as about any single tool.",
    ),
  },
  {
    slug: "legal-knowledge-base",
    parentSlug: "aws-data-ml-platform",
    title: "Legal Knowledge Base Assistant",
    label: "Professional Project — anonymized for confidentiality",
    tags: ["AWS", "RAG", "Applied AI", "Knowledge Retrieval"],
    summary: "A cloud-native legal knowledge assistant that retrieves contracts, policies and regulatory references to produce grounded, source-aware answers.",
    role: "Cloud Solutions Engineer — serverless architecture and RAG orchestration.",
    problem: "Growing repositories of contracts and internal precedents made manual document review and repetitive legal lookups slow, delaying decisions.",
    approach: "Use a lightweight chat interface, API Gateway and Python Lambda to retrieve relevant documents from S3, augment the prompt and generate grounded answers with Amazon Bedrock.",
    outcome: "Faster legal information retrieval, fewer repetitive lookups and a scalable, pay-per-use architecture with minimal infrastructure maintenance.",
    stack: ["AWS Lambda", "Amazon S3", "API Gateway", "Amazon Bedrock", "Claude 3 Sonnet", "Python", "Serverless", "RAG", "IAM"],
    flow: ["Web Chat", "API Gateway", "Lambda", "S3 Retrieval", "Augmented Prompt", "Bedrock", "Grounded Answer"],
    links: [{ label: "Original case study", href: "https://kehinde-solutions.vercel.app/case-studies/legal-knowledge-base" }],
    study: S(
      "Legal teams needed easier access to contracts, internal policies, legal references and precedents. As the corpus grew, finding a specific clause became increasingly resource-intensive.",
      "A centralized Amazon S3 corpus holds legal documents and internal references. Private buckets, versioning and lifecycle policies support secure, durable document storage.",
      "Retrieval-Augmented Generation grounds each answer in relevant source documents rather than relying on model memory. Users ask questions through a lightweight web chat interface.",
      "Web Chat → API Gateway → Python Lambda → relevant S3 documents → augmented prompt → Amazon Bedrock → summarized, source-aware response. API Gateway separates the interface from the retrieval and generation layers.",
      "The Python Lambda handler orchestrates document retrieval, context assembly and Bedrock invocation. Serverless/YAML definitions describe API resources. Least-privilege IAM restricts S3 reads and model invocation; private S3 buckets and API Gateway authorization protect access.",
      "Amazon Bedrock with Claude 3 Sonnet generates responses using retrieved context. Retrieval and prompt-building are tuned to balance answer relevance with latency as document volume grows.",
      "A simple chat interface submits legal questions and displays grounded responses. Managed AWS services and stateless compute scale with usage without maintaining servers.",
      "Improved legal knowledge accessibility, faster information retrieval and reduced repetitive lookups. The pay-per-use design lowers infrastructure management overhead.",
      "RAG over model recall reduces hallucination risk and anchors answers to company documents. S3 provides durable centralized storage; serverless compute balances scale and operational simplicity.",
      "Relevant retrieval is essential as the corpus grows. Passing the right amount of context preserves response quality without unnecessary latency; security must be designed into every layer.",
    ),
  },
  {
    slug: "reliability-data-pipeline",
    title: "AI-Powered SRE Weekly Reliability Reporting Automation",
    label: "Professional Project — anonymized for confidentiality",
    tags: ["Data Engineering", "Python", "Observability", "Automation", "Applied AI"],
    summary: "A scheduled pipeline that collects production telemetry, aggregates reliability KPIs, generates AI-powered executive summaries and publishes weekly reports to Notion and Slack.",
    role: "SRE / DevOps Engineer — designed and implemented the automated reliability reporting solution in a FinTech production engagement.",
    problem: "Engineers spent hours collecting metrics and incident logs across monitoring systems, analyzing reliability and manually formatting stakeholder reports.",
    approach: "Orchestrate scheduled collection with n8n, aggregate Datadog, New Relic and CloudWatch metrics in Google Sheets, generate OpenAI summaries and automate Notion publication and Slack delivery.",
    outcome: "Manual reporting moved from hours to minutes, with consistent reports, faster delivery and clearer stakeholder visibility.",
    stack: ["AWS", "Datadog", "New Relic", "CloudWatch", "n8n", "OpenAI", "Google Sheets", "Notion", "Slack", "Python"],
    flow: ["Monitoring", "Data Collection", "KPI Processing", "AI Analysis", "Notion", "Slack"],
    links: [{ label: "Original case study", href: "https://kehinde-solutions.vercel.app/case-studies/sre-reporting" }],
    study: S(
      "Engineering teams need a reliable weekly view of uptime, incident trends and platform health. Manual collection, analysis and report formatting consumed time and produced inconsistent stakeholder narratives.",
      "Datadog, New Relic and AWS CloudWatch provide uptime, incident logs and operational metrics. Centralized aggregation in Google Sheets makes the reliability data transparent before it enters AI analysis.",
      "Schedule collection, normalize monitoring signals, compute reliability indicators, generate executive summaries, publish the report and notify stakeholders. Keep monitoring, processing, AI and delivery independently maintainable.",
      "Monitoring & Observability → Data Collection → Data Processing → AI Analysis → Knowledge & Reporting → Notification & Delivery. n8n schedules and coordinates API integrations; Google Sheets provides the aggregation layer, Notion the archive and Slack the notification surface.",
      "Python API integrations collect monitoring data, including Datadog SLOs and New Relic uptime. n8n coordinates scheduled execution, aggregation and publishing; standardized templates give each report a consistent shape.",
      "Structured SRE prompts with OpenAI GPT-4o-mini translate reliability KPIs into calm, factual summaries covering uptime versus SLO, top incidents and MTTR, regressions and improvements.",
      "Weekly reports are published to Notion as a durable, searchable historical archive. Slack notifies engineering and stakeholders when the latest report is ready.",
      "Reporting effort reduced from hours to minutes. Consistent, high-signal executive narratives improve visibility, speed delivery and establish a repeatable reporting quality bar.",
      "Google Sheets keeps aggregated metrics inspectable before summarization. Notion preserves knowledge beyond ephemeral Slack messages. Separating collection, processing and reporting improves maintainability and independent scalability.",
      "Centralized collection is a prerequisite for meaningful AI analysis. Structured prompts and standardized report templates make operational summaries useful and consistent regardless of incident volume.",
    ),
  },
  {
    slug: "profit-distribution-engine",
    title: "Automated Profit Distribution Report Generator",
    label: "Personal Project",
    tags: ["FinTech", "Data Processing", "Business Rules", "Financial Analytics", "AI Automation"],
    summary: "AI-powered investment settlement automation that transforms contribution spreadsheets into investor-ready PDF reports and email delivery in under 60 seconds.",
    role: "Automation Engineer & Solutions Architect — designed and implemented the end-to-end settlement workflow.",
    problem: "Islamic cooperatives and investment clubs manually calculated ownership and profit allocations, prepared reports and contacted investors, creating repetitive work, spreadsheet errors and reporting inconsistencies.",
    approach: "Retrieve and validate Google Sheets contributions, calculate proportional allocations with deterministic JavaScript, generate Groq summaries, produce templated PDFs and deliver statements by email through n8n.",
    outcome: "Settlement processing reduced from hours to under 60 seconds, eliminating repetitive manual calculations and producing consistent investor-ready reports.",
    stack: ["n8n", "Google Sheets", "JavaScript", "Groq API", "PDF Generation", "Email Automation", "Financial Logic"],
    flow: ["Investment Data", "Validation & Calculation", "Groq Summary", "PDF Generation", "Email Distribution"],
    links: [
      { label: "GitHub", href: "https://github.com/Kehindeadebisi/profit-distribution-api" },
      { label: "Original case study", href: "https://kehinde-solutions.vercel.app/case-studies/profit-distribution" },
    ],
    study: S(
      "Islamic cooperative societies, investment clubs and profit-sharing organizations often handle quarterly distributions manually. Exporting contributions, calculating allocations, preparing statements and communicating results becomes harder to scale as membership grows.",
      "Google Sheets is the source of truth for investor records, contribution amounts and quarterly profit pool values. The operator provides the quarterly pool input and the workflow retrieves member contributions.",
      "An end-to-end n8n workflow validates investment records, calculates ownership percentages and individual profit allocations, generates AI-written investment summaries, creates professional PDF reports and emails them to investors.",
      "Five separate layers: Investment Data (Google Sheets) → Processing & Calculation (n8n) → AI Intelligence (Groq API) → Document Generation (PDF) → Distribution (Email). Modular components support reuse across multiple funds.",
      "The 13-step workflow includes record validation and allocation checks before report generation. Custom JavaScript calculates each member’s ownership as contribution ÷ total contributions, and profit share as that proportion × the quarterly pool. The example rounds ownership percentages to four decimals and profit shares to two.",
      "Groq’s llama-3.1-70b-versatile generates plain-language quarterly investment summaries from structured allocation results. AI explains the results; deterministic financial logic, not the language model, determines allocations.",
      "Branded PDF templates provide per-member settlement statements and distribution summaries. Automated emails carry investor notifications and PDF attachments, removing manual formatting and delivery work.",
      "Quarterly settlements move from hours to under 60 seconds. Repetitive manual calculations are eliminated, reporting consistency improves and spreadsheet error risk falls. The workflow is reusable across funds with configuration changes.",
      "Separate data, calculation, AI, reporting and distribution so each can evolve independently. Groq was chosen for fast, cost-effective summarization; structured PDF templates combined with AI narratives balance professionalism and accessibility.",
      "Validate before generating reports. Financial accuracy depends on deterministic allocation checks, while clear narratives make the output accessible to non-technical investors. Modular business rules and delivery layers make the automation reusable.",
    ),
  },
  {
    slug: "automated-financial-reporting",
    title: "Automated Financial Reporting with Power BI & DAX",
    label: "Case Study / Analytical Project",
    tags: ["Power BI", "DAX", "Financial Analytics", "BI"],
    summary: "A financial reporting system built around reusable data models, measures and business KPIs.",
    role: "Built the data model, DAX measures and reporting layer.",
    problem: "Financial reporting built by hand is slow and inconsistent. Decision-makers need KPIs that update from a reliable model.",
    approach: "Model the raw financial data, define reusable DAX measures for core KPIs, and build an automated reporting layer on top.",
    outcome: "A reporting layer where KPIs come from one consistent model instead of manual spreadsheets.",
    stack: ["Power BI", "DAX", "Data Modelling", "Financial KPIs"],
    flow: ["Raw Data", "Data Model", "Measures", "KPIs", "Dashboard", "Decision"],
    links: [
      { label: "Presentation", href: "https://docs.google.com/presentation/d/1KJwc2wsxLiEOX8C6FCXxTdvSU4E-sSiI/edit?usp=sharing&ouid=102852082257751769020&rtpof=true&sd=true" },
    ],
    study: S(
      "Financial stakeholders needed consistent, repeatable KPI reporting.",
      "Raw financial and business transaction data.",
      "Model first, visualise second — a solid model makes every report trustworthy.",
      "Raw Data → Data Model → Measures → KPIs → Dashboard → Decision.",
      "Relationships and tables structured in Power BI; calculated measures written in DAX.",
      "Financial KPIs defined as reusable measures for consistent analysis.",
      "Automated Power BI reports for business decision support.",
      "A reusable reporting system rather than a one-off dashboard.",
      "Power BI and DAX keep logic centralised in the model so every visual uses the same definitions.",
      "The measure layer is where reporting quality is won or lost.",
    ),
  },
  {
    slug: "bedrest-data-model",
    title: "BedRest Sales & Store Performance Data Model",
    label: "Case Study / Analytical Project",
    tags: ["Excel", "Power Pivot", "Data Modeling", "BI"],
    summary: "A dimensional BI model in Excel/Power Pivot relating dates, managers, stores, products and commission to drive business and store performance reporting.",
    role: "Designed the workbook model and reporting views.",
    problem: "Sales and store performance data across stores, managers and products needed to be analysed together for management reporting.",
    approach: "Structure the workbook as related entity tables (Dates, Managers, Stores, Products, Commission), connect them in Power Pivot, and build pivot-based reporting views.",
    outcome: "Business Overview and Store Performance views driven by a structured, related data model.",
    stack: ["Excel", "Power Pivot", "Pivot Tables", "Calculated Measures", "Data Modeling"],
    flow: ["Dates · Managers · Stores · Products · Commission", "Power Pivot Model", "Measures", "Business Overview", "Store Performance"],
    links: [
      { label: "Workbook", href: "https://github.com/Kehindeadebisi/Dashboards/blob/main/Bed%20Rest%20Dashboard.xlsx?raw=true" },
    ],
    study: S(
      "A retail business needed management reporting across stores, managers and products.",
      "Workbook sheets: Dates, Managers, Stores, Products, Commission, plus reporting sheets Business Overview and Store Performance.",
      "Apply dimensional thinking inside Excel: separate entities into tables and relate them.",
      "Entity tables → Power Pivot data model → measures → Business Overview / Store Performance.",
      "Relationships between business entities defined in Power Pivot.",
      "Calculated measures and Pivot Tables for business and store performance analysis.",
      "Two reporting sheets for management: Business Overview and Store Performance.",
      "Demonstrates structured, dimensional modelling in a widely used business tool.",
      "Power Pivot gives relational modelling inside Excel, where the business already works.",
      "Dimensional modelling principles apply whatever the tool.",
    ),
  },
];

export const EXPERIENCE = [
  {
    company: "Fincra", role: "Platform Engineer", period: "Jan 2025 – 2026",
    story: "Production data, operational telemetry, automation and engineering systems.",
    points: [
      "Built an automated reliability reporting workflow turning monitoring data into weekly KPI reports — saving ~6 hours/week.",
      "AWS infrastructure with Terraform; CI/CD pipelines with GitHub Actions.",
      "Observability with New Relic and Datadog; incident analysis and reliability metrics.",
      "Python automation across production systems and operational reporting.",
    ],
    stack: ["AWS", "Terraform", "GitHub Actions", "Python", "New Relic", "Datadog"],
  },
  {
    company: "Datamellon", role: "Cloud Solutions Engineer – Data/AI", period: "Oct 2023 – Dec 2024",
    story: "Cloud data platforms, ETL/ELT and ML workflows on AWS.",
    points: [
      "Built ETL/ELT workflows with AWS Glue and Python over S3-based storage.",
      "Worked with Redshift and DynamoDB as warehouse and operational data stores.",
      "Supported machine-learning workflows with SageMaker.",
    ],
    stack: ["AWS Glue", "S3", "Redshift", "DynamoDB", "SageMaker", "Python"],
  },
  {
    company: "NVIT", role: "Data Analytics Engineer", period: "Jul 2022 – Jul 2023",
    story: "Analytics engineering — pipelines, SQL and business KPIs.",
    points: [
      "Built data pipelines and ETL processes in Python and SQL.",
      "Developed business KPIs, reporting and analytical workflows.",
      "Delivered BI reporting for stakeholders.",
    ],
    stack: ["Python", "SQL", "ETL", "BI"],
  },
  {
    company: "Digital Bananas", role: "Data Analyst", period: "Dec 2020 – Jul 2022",
    story: "Reporting and marketing/CRM analytics.",
    points: [
      "Power BI and Excel reporting on business KPIs.",
      "Marketing and CRM analytics; stakeholder reporting.",
    ],
    stack: ["Power BI", "Excel"],
  },
  {
    company: "Jaiz Bank", role: "Business Development Officer", period: "Dec 2018 – Mar 2020",
    story: "Financial-services domain foundation.",
    points: ["SME and business finance, customer and business analysis, commercial understanding."],
    stack: ["Financial Services"],
  },
];

export type Cat = "Data Engineering" | "BI" | "FinTech" | "ML" | "Cloud" | "Automation";
export const MORE_WORK: { title: string; desc: string; href: string; cats: Cat[]; tool: string }[] = [
  { title: "Dimensional Data Modeling", desc: "Data modelling exercises demonstrating fact/dimension design and dimensional data architecture.", href: "https://github.com/Kehindeadebisi/cde_data_model", cats: ["Data Engineering"], tool: "SQL · Modeling" },
  { title: "Bash & SQL ETL Pipeline", desc: "A command-line ETL workflow that downloads, transforms and extracts structured data using Bash and SQL-oriented processing.", href: "https://github.com/Kehindeadebisi/Bash_SQL_ETL", cats: ["Data Engineering"], tool: "Bash · SQL" },
  { title: "Airflow Data Pipeline", desc: "Data pipeline orchestration using Apache Airflow.", href: "https://github.com/Kehindeadebisi/Wiki_Airflow", cats: ["Data Engineering"], tool: "Airflow · Python" },
  { title: "Azure Cloud Data Lake", desc: "Cloud data lake work using Azure CLI/Python and distributed data processing concepts.", href: "https://github.com/Kehindeadebisi/DEC-Azure-Script", cats: ["Data Engineering", "Cloud"], tool: "Azure · Python" },
  { title: "Excel VBA Data Entry System", desc: "Records submissions into a database sheet while capturing user, date and time metadata — structured entry, audit metadata and less repetitive manual work.", href: "https://github.com/Kehindeadebisi/Excel-VBA-User-Form", cats: ["Automation"], tool: "Excel VBA" },
  { title: "Riby Business Intelligence Case Study", desc: "A BI case study analysing business data and presenting findings.", href: "https://docs.google.com/presentation/d/e/2PACX-1vT-3-f1cXmChGsqT-_cg0PkG0l74Jy0qLxxzJSxITtcMA5vEbQGcIoKHE1iQAmoKQ/pub?start=true&loop=true&delayms=10000&slide=id.p1", cats: ["BI", "FinTech"], tool: "Case study" },
  { title: "Tableau Trading Dashboard", desc: "Market analytics and technical-analysis dashboard built with Tableau.", href: "https://public.tableau.com/app/profile/kehinde.adebisi/viz/TradingDashboard_16636074415530/DowJonesTechnicalAnalysis?publish=yes", cats: ["BI", "FinTech"], tool: "Tableau" },
  { title: "Monte Carlo Net Income Forecast", desc: "Probabilistic financial forecasting using Monte Carlo simulation to model potential net-income outcomes.", href: "https://github.com/Kehindeadebisi/Monte-Carlo-Simulation/blob/main/Net-Income-Forecast.ipynb", cats: ["FinTech", "ML"], tool: "Python · Simulation" },
];

export const EARLIER_ML = [
  { title: "Nigerian House Rent Prediction", desc: "End-to-end ML predicting Nigerian rental prices from scraped, processed property data, delivered via a Flask app.", href: "https://github.com/Kehindeadebisi/Housing-Prediction" },
  { title: "Ad Click Prediction", desc: "Classification model predicting ad clicks.", href: "https://nbviewer.org/github/Kehindeadebisi/Ad-Click-Prediction/blob/main/Ad-Click%20Prediction.ipynb" },
  { title: "Restaurant Analysis", desc: "Exploratory analysis of restaurant order data.", href: "https://nbviewer.org/github/Kehindeadebisi/Restaurant_Analysis_Prediction/blob/main/Restaurant_Order_Analysis.ipynb" },
  { title: "Food Price EDA & Prediction", desc: "Exploratory analysis and price prediction.", href: "https://github.com/Kehindeadebisi?tab=repositories" },
  { title: "Earlier House Price Prediction", desc: "An early regression project.", href: "https://nbviewer.org/github/Kehindeadebisi/Housing-Prediction/blob/main/files%20for%20trained%20models/Housing_Prices.ipynb" },
];

export const SKILLS: Record<string, string[]> = {
  "Data Engineering": ["Python", "SQL", "ETL / ELT", "Data Pipelines", "AWS Glue", "S3", "Redshift", "APIs", "Data Transformation", "Airflow", "Bash"],
  "Analytics & BI": ["Power BI", "DAX", "Pandas", "Excel", "Power Pivot", "Tableau", "KPI Development", "Dashboard Design", "Business Analysis"],
  "Cloud Data": ["AWS", "Azure", "S3", "AWS Glue", "Redshift", "Lambda", "DynamoDB", "SageMaker"],
  "Data & ML": ["Machine Learning", "XGBoost", "Forecasting", "Monte Carlo Simulation", "Feature Engineering", "Statistical Analysis"],
  Engineering: ["Git", "GitHub", "GitHub Actions", "Docker", "Terraform", "Linux", "CI/CD"],
  "FinTech & Business": ["Financial Analytics", "Liquidity Analysis", "Financial Modelling", "Operational Analytics", "Risk Analysis", "Financial Reporting", "Decision Support"],
};
